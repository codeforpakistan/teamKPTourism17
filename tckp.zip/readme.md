Install it

`$ npm i`

Run it

`$ npm run start`

Build it

`$ npm run build`

Watch it

`$ npm run watch`
