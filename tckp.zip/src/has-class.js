export default (element,className)=>element.classList.contains(className)
